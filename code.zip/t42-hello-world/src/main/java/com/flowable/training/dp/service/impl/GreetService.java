package com.flowable.training.dp.service.impl;

import java.util.List;

import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.history.HistoricProcessInstance;
import org.springframework.stereotype.Service;

@Service("greetService")
public class GreetService {

    private final HistoryService historyService;

    public GreetService(HistoryService historyService) {
        this.historyService = historyService;
    }

    public void greet(String message, DelegateExecution delegateExecution) {
        System.out.println(message);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
