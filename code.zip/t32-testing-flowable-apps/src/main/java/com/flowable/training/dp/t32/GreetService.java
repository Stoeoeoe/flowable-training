package com.flowable.training.dp.t32;

import org.springframework.stereotype.Service;

@Service("greetService")
public class GreetService {

    public void greet(String message) {
        System.out.println(message);
    }

}
