package com.flowable.training.dp.rest;

import java.util.ArrayList;
import java.util.List;

import org.flowable.common.rest.api.DataResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.aspose.cells.TextTabStopCollection;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowable.core.idm.api.PlatformIdentityService;
import com.flowable.core.idm.api.PlatformUser;
import com.flowable.idm.dto.PlatformUserResponse;
import com.flowable.idm.rest.service.api.IdmRestResponseFactory;

@RestController
public class CustomRestDemoResource {

    private final PlatformIdentityService platformIdentityService;
    private final ObjectMapper objectMapper;

    public CustomRestDemoResource(PlatformIdentityService platformIdentityService, ObjectMapper objectMapper) {
        this.platformIdentityService = platformIdentityService;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/api/all-users-starting-with/{letter}")
    public DataResponse<PlatformUserResponse> getAllUsersStartingWith(@PathVariable String letter) {
        List<PlatformUser> platformUsers = platformIdentityService.createPlatformUserQuery()
            .userFirstNameLikeIgnoreCase(letter + "%")
            .includeIdentityInfo()
            .list();

        PlatformUserResponse response = new PlatformUserResponse();
        IdmRestResponseFactory restResponseFactory = new IdmRestResponseFactory(objectMapper);

        List<PlatformUserResponse> responses = new ArrayList<>();
        for (PlatformUser platformUser : platformUsers) {
            PlatformUserResponse platformUserResponse = restResponseFactory.createPlatformUserResponse(platformUser);
            responses.add(platformUserResponse);
        }

        DataResponse<PlatformUserResponse> dataResponse = new DataResponse<>();
        dataResponse.setData(responses);
        dataResponse.setStart(0);
        dataResponse.setSize(platformUsers.size());
        dataResponse.setSort("name");
        dataResponse.setOrder("asc");
        return dataResponse;
    }

}
