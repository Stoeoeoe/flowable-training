#!/bin/bash

# @marp-team/marp-cli v0.12.1 (w/ bundled @marp-team/marp-core v0.12.0)
marp --pptx --allow-local-files PITCHME.md