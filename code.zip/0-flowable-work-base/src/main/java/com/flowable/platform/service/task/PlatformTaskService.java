package com.flowable.platform.service.task;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.flowable.cmmn.api.CmmnHistoryService;
import org.flowable.cmmn.api.CmmnRepositoryService;
import org.flowable.cmmn.api.CmmnRuntimeService;
import org.flowable.cmmn.api.CmmnTaskService;
import org.flowable.cmmn.api.history.HistoricCaseInstance;
import org.flowable.cmmn.api.repository.CaseDefinition;
import org.flowable.cmmn.api.runtime.CaseInstance;
import org.flowable.common.engine.api.FlowableForbiddenException;
import org.flowable.common.engine.api.FlowableIllegalArgumentException;
import org.flowable.common.engine.api.FlowableObjectNotFoundException;
import org.flowable.common.engine.api.scope.ScopeTypes;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.form.api.FormInfo;
import org.flowable.form.api.FormInstance;
import org.flowable.form.api.FormRepositoryService;
import org.flowable.form.api.FormService;
import org.flowable.identitylink.api.IdentityLinkInfo;
import org.flowable.idm.api.User;
import org.flowable.rest.service.api.engine.RestIdentityLink;
import org.flowable.task.api.DelegationState;
import org.flowable.task.api.Task;
import org.flowable.task.api.TaskInfo;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.flowable.variable.api.history.HistoricVariableInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowable.core.content.api.CoreContentItem;
import com.flowable.core.content.api.CoreContentService;
import com.flowable.core.content.api.DocumentRepositoryService;
import com.flowable.core.content.api.MetadataService;
import com.flowable.form.engine.impl.FormServiceImpl;
import com.flowable.form.engine.impl.util.FormModelUtil;
import com.flowable.form.model.FlowableFormModel;
import com.flowable.license.LicenseCheckService;
import com.flowable.platform.common.form.FormPayloadVariables;
import com.flowable.platform.security.permission.PermissionConstants;
import com.flowable.platform.security.permission.TaskPermissionService;
import com.flowable.platform.security.service.AbstractPlatformSecurityService;
import com.flowable.platform.service.content.DocumentMetadataHandler;
import com.flowable.platform.service.content.PlatformContentItemService;
import com.flowable.platform.service.license.PlatformFlowableProduct;
import com.flowable.platform.service.util.VariableUtil;
import com.flowable.platform.service.variable.PlatformRestVariableTransformer;

/**
 * @author Yvo Swillens
 */
@Transactional
public class PlatformTaskService extends AbstractPlatformSecurityService {

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected CmmnTaskService cmmnTaskService;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected CmmnRuntimeService cmmnRuntimeService;

    @Autowired
    protected RepositoryService repositoryService;

    @Autowired
    protected CmmnRepositoryService cmmnRepositoryService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    protected CmmnHistoryService cmmnHistoryService;

    @Autowired
    protected FormRepositoryService formRepositoryService;

    @Autowired
    protected FormService formService;

    @Autowired
    protected LicenseCheckService licenseCheckService;

    @Autowired
    protected TaskPermissionService permissionService;

    @Autowired(required = false)
    protected PlatformContentItemService contentItemService;

    @Autowired(required = false)
    protected CoreContentService contentService;

    @Autowired(required = false)
    protected DocumentRepositoryService documentRepositoryService;

    @Autowired(required = false)
    protected MetadataService metadataService;

    @Autowired(required = false)
    protected DocumentMetadataHandler documentMetadataHandler;

    @Autowired
    protected ObjectMapper objectMapper;

    public TaskRepresentation getTask(String taskId) {
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        TaskRepresentation taskRepresentation = null;
        List<? extends IdentityLinkInfo> identityLinks = null;
        if (task == null) {
            HistoricTaskInstance historicTask = historyService.createHistoricTaskInstanceQuery().taskId(taskId).singleResult();

            if (historicTask == null) {
                throw new FlowableObjectNotFoundException(String.format("Task not found with id: %s", taskId));
            }

            taskRepresentation = createTaskRepresentation(historicTask);

            if (taskRepresentation.getProcessInstanceId() != null) {
                identityLinks = historyService.getHistoricIdentityLinksForTask(taskId);
                HistoricProcessInstance processInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(taskRepresentation.getProcessInstanceId()).singleResult();
                if (processInstance != null) {
                    taskRepresentation.setProcessInstanceName(processInstance.getName());
                }

            } else if (taskRepresentation.getScopeId() != null && ScopeTypes.CMMN.equals(taskRepresentation.getScopeType())) {
                identityLinks = cmmnHistoryService.getHistoricIdentityLinksForTask(taskId);
                HistoricCaseInstance caseInstance = cmmnHistoryService.createHistoricCaseInstanceQuery().caseInstanceId(taskRepresentation.getScopeId()).singleResult();
                if (caseInstance != null) {
                    taskRepresentation.setCaseInstanceName(caseInstance.getName());
                }

            } else {
                identityLinks = historyService.getHistoricIdentityLinksForTask(taskId);
            }

        } else {
            taskRepresentation = createTaskRepresentation(task);

            if (taskRepresentation.getProcessInstanceId() != null) {
                identityLinks = taskService.getIdentityLinksForTask(taskId);
                ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(taskRepresentation.getProcessInstanceId()).singleResult();
                if (processInstance != null) {
                    taskRepresentation.setProcessInstanceName(processInstance.getName());
                }

            } else if (taskRepresentation.getScopeId() != null && ScopeTypes.CMMN.equals(taskRepresentation.getScopeType())) {
                identityLinks = cmmnTaskService.getIdentityLinksForTask(taskId);
                CaseInstance caseInstance = cmmnRuntimeService.createCaseInstanceQuery().caseInstanceId(taskRepresentation.getScopeId()).singleResult();
                if (caseInstance != null) {
                    taskRepresentation.setCaseInstanceName(caseInstance.getName());
                }

            } else {
                identityLinks = taskService.getIdentityLinksForTask(taskId);
            }
        }

        if (taskRepresentation.getProcessDefinitionId() != null) {
            List<String> permissions = null;
            if (task != null) {
                permissions = permissionService.getRuntimeTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getProcessInstanceId(), taskRepresentation.getProcessDefinitionId(), ScopeTypes.BPMN,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            } else {
                permissions = permissionService.getHistoricTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getProcessInstanceId(), taskRepresentation.getProcessDefinitionId(), ScopeTypes.BPMN,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            }

            if (!permissions.contains(PermissionConstants.TASK_VIEW)) {
                throw new FlowableForbiddenException("User has no read permission on task " + taskId);
            }

            ProcessDefinition processDefinition = repositoryService.getProcessDefinition(taskRepresentation.getProcessDefinitionId());
            taskRepresentation.setProcessDefinitionName(processDefinition.getName());
            taskRepresentation.setPermissions(permissions);

        } else if (taskRepresentation.getScopeDefinitionId() != null && ScopeTypes.CMMN.equals(taskRepresentation.getScopeType())) {
            List<String> permissions = null;
            if (task != null) {
                permissions = permissionService.getRuntimeTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getScopeId(), taskRepresentation.getScopeDefinitionId(), ScopeTypes.CMMN,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            } else {
                permissions = permissionService.getHistoricTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getScopeId(), taskRepresentation.getScopeDefinitionId(), ScopeTypes.CMMN,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            }

            if (!permissions.contains(PermissionConstants.TASK_VIEW)) {
                throw new FlowableForbiddenException("User has no read permission on task " + taskId);
            }

            CaseDefinition caseDefinition = cmmnRepositoryService.getCaseDefinition(taskRepresentation.getScopeDefinitionId());
            taskRepresentation.setCaseDefinitionName(caseDefinition.getName());
            taskRepresentation.setPermissions(permissions);

        } else {
            List<String> permissions = null;
            if (task != null) {
                permissions = permissionService.getRuntimeTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getParentTaskId(), null, ScopeTypes.TASK,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            } else {
                permissions = permissionService.getHistoricTaskPermissions(taskRepresentation.getId(), taskRepresentation.getTaskDefinitionKey(),
                    taskRepresentation.getParentTaskId(), null, ScopeTypes.TASK,
                    taskRepresentation.getAssignee(), taskRepresentation.getOwner(), identityLinks, taskRepresentation.getTenantId());
            }

            if (!permissions.contains(PermissionConstants.TASK_VIEW)) {
                throw new FlowableForbiddenException("User has no read permission on task " + taskId);
            }

            taskRepresentation.setPermissions(permissions);
        }

        return taskRepresentation;
    }

    @Autowired
    protected PlatformRestVariableTransformer variableTransformer;

    public void completeTaskForm(String taskId, CompleteFormRepresentation formRepresentation) {
        licenseCheckService.executeLicenseCheck(PlatformFlowableProduct.WORK, PlatformFlowableProduct.ENGAGE, PlatformFlowableProduct.PLATFORM);

        // Get the form definition
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        if (task == null) {
            throw new FlowableObjectNotFoundException(String.format("Task not found with id: %s", taskId));
        }

        permissionService.validatePermissionForRuntimeScope(PermissionConstants.TASK_COMPLETE, taskId, getCurrentUserId(),
            getCurrentGroupKeys(), getCurrentTenantId());

        Map<String, Object> variables = formRepresentation.getValues();
        if (StringUtils.isNotEmpty(task.getFormKey())) {
            if (task.getScopeId() != null && ScopeTypes.CMMN.equals(task.getScopeType())) {
                FormInfo taskFormInfo = cmmnTaskService.getTaskFormModel(task.getId(), true);
                cmmnTaskService.completeTaskWithForm(taskId, taskFormInfo.getId(), formRepresentation.getOutcome(),
                    variables);
            } else {
                FormInfo taskFormInfo = taskService.getTaskFormModel(task.getId(), true);
                taskService.completeTaskWithForm(taskId, taskFormInfo.getId(),
                    formRepresentation.getOutcome(), variables);
            }

        } else if (MapUtils.isEmpty(variables)) {
            if (task.getScopeId() != null && ScopeTypes.CMMN.equals(task.getScopeType())) {
                cmmnTaskService.complete(task.getId(), variables);
            } else {
                taskService.complete(taskId, variables);
            }
        } else {
            throw new FlowableForbiddenException("Completing a task without form is not allowed to pass variables");
        }
    }

    public void saveTaskForm(String taskId, SaveFormRepresentation saveFormRepresentation, User user) {
        licenseCheckService.executeLicenseCheck(PlatformFlowableProduct.WORK, PlatformFlowableProduct.ENGAGE, PlatformFlowableProduct.PLATFORM);

        // Get the form definition
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        if (task == null) {
            throw new FlowableObjectNotFoundException(String.format("Task not found with id: %s", taskId));
        }

        if (StringUtils.isEmpty(task.getFormKey())) {
            throw new FlowableObjectNotFoundException(String.format("Task has no form with task id: %s", taskId));
        }

        permissionService.validatePermissionForRuntimeScope(PermissionConstants.TASK_EDIT, taskId,
            getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());

        FormInfo formInfo = null;
        if (task.getProcessInstanceId() != null) {
            formInfo = taskService.getTaskFormModel(task.getId(), true);
        } else {
            formInfo = cmmnTaskService.getTaskFormModel(task.getId(), true);
        }

        Map<String, Object> formVariables = saveFormRepresentation.getValues();
        formVariables.remove(FormPayloadVariables.PAYLOAD_VARIABLE_NAME);
        formVariables.remove(FormPayloadVariables.PAYLOAD_DATETIME_VARIABLE_NAME);
        formVariables.remove(FormPayloadVariables.PAYLOAD_HASH_VARIABLE_NAME);

        if (task.getProcessInstanceId() != null) {
            formService.saveFormInstanceByFormDefinitionId(formVariables, formInfo.getId(), taskId,
                task.getProcessInstanceId(), task.getProcessDefinitionId(), task.getTenantId(), null);

        } else {
            formService.saveFormInstanceWithScopeId(formVariables, formInfo.getId(), taskId,
                task.getScopeId(), task.getScopeType(), task.getScopeDefinitionId(), task.getTenantId(), null);
        }

        Map<String, Object> formAttachments = this.mapAttachmentsToContentItems(formVariables);
        if(!formAttachments.isEmpty()) {
            Set<String> attachmentKeys = formAttachments.keySet();
            attachmentKeys.forEach(key -> {
                List<CoreContentItem> contentItems = (List<CoreContentItem>) formAttachments.get(key) ;
                List<Map<String, Object>> attachmentVariables = (List<Map<String, Object>>) formVariables.get(key);
                documentMetadataHandler.handleVariableForContentItems(attachmentVariables, contentItems);
            });
        }
    }

    @SuppressWarnings("unchecked")
    public void saveDocuments(String taskId, Map<String, Object> variables) {
        licenseCheckService.executeLicenseCheck(PlatformFlowableProduct.WORK, PlatformFlowableProduct.ENGAGE, PlatformFlowableProduct.PLATFORM);

        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        if (task == null) {
            throw new FlowableObjectNotFoundException(String.format("Task not found with id: %s", taskId));
        }

        if (contentService == null || metadataService == null || !variables.containsKey("attachments")) {
            return;
        }

        permissionService.validatePermissionForRuntimeScope(PermissionConstants.TASK_EDIT, taskId,
            getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());

        List<CoreContentItem> contentItems = contentService.createCoreContentItemQuery().taskId(taskId).list();
        List<Map<String, Object>> attachmentVariables = (List<Map<String, Object>>) variables.get("attachments");

        documentMetadataHandler.handleVariableForContentItems(attachmentVariables, contentItems);
    }

    public Map<String, Object> getTaskVariablesWithPermissionCheck(String taskId) {
        permissionService.validatePermissionForScope(PermissionConstants.TASK_VIEW, taskId,
            getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());
        return getTaskVariables(taskId);
    }

    public Map<String, Object> getTaskVariables(String taskId) {
        Map<String, Object> variableMap = null;
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (task != null) {
            variableMap = variableTransformer.transformVariables(taskService.getVariables(taskId));

            if (task.getProcessInstanceId() != null) {
                ProcessInstance processInstance = runtimeService.createProcessInstanceQuery()
                    .processInstanceId(task.getProcessInstanceId())
                    .singleResult();

                VariableUtil.addProcessInstanceVariables(processInstance, variableMap, runtimeService,
                    cmmnRuntimeService, contentItemService, variableTransformer);

            } else if (task.getScopeId() != null && ScopeTypes.CMMN.equals(task.getScopeType())) {
                CaseInstance caseInstance = cmmnRuntimeService.createCaseInstanceQuery()
                    .caseInstanceId(task.getScopeId())
                    .singleResult();

                VariableUtil.addCaseInstanceVariables(caseInstance, variableMap, runtimeService,
                    cmmnRuntimeService, contentItemService, variableTransformer);
            }

            VariableUtil.addTaskVariables(task, variableMap, taskService, variableTransformer);

        } else {
            variableMap = new HashMap<>();
            HistoricTaskInstance historicTask = historyService.createHistoricTaskInstanceQuery().taskId(taskId).singleResult();
            if (historicTask == null) {
                throw new FlowableObjectNotFoundException(String.format("Task with id: %s does not exist", taskId));
            }

            List<HistoricVariableInstance> historicVariables;
            if (historicTask.getProcessInstanceId() != null) {
                historicVariables = historyService.createHistoricVariableInstanceQuery().processInstanceId(historicTask.getProcessInstanceId()).list();

                HistoricProcessInstance processInstance = historyService.createHistoricProcessInstanceQuery()
                    .processInstanceId(historicTask.getProcessInstanceId())
                    .singleResult();

                VariableUtil.addHistoricProcessInstanceVariables(processInstance, variableMap,
                    historyService, cmmnHistoryService, contentItemService, variableTransformer);

            } else if (historicTask.getScopeId() != null && ScopeTypes.CMMN.equals(historicTask.getScopeType())) {
                historicVariables = cmmnHistoryService.createHistoricVariableInstanceQuery().caseInstanceId(historicTask.getScopeId()).list();
                HistoricCaseInstance caseInstance = cmmnHistoryService.createHistoricCaseInstanceQuery()
                    .caseInstanceId(historicTask.getScopeId())
                    .singleResult();

                VariableUtil.addHistoricCaseInstanceVariables(caseInstance, variableMap,
                    historyService, cmmnHistoryService, contentItemService, variableTransformer);

            } else {
                historicVariables = historyService.createHistoricVariableInstanceQuery().taskId(historicTask.getId()).list();
            }

            if (historicVariables != null) {
                for (HistoricVariableInstance historicVariable : historicVariables) {
                    variableMap.put(historicVariable.getVariableName(), variableTransformer.transformVariable(historicVariable.getValue()));
                }
            }

            VariableUtil.addTaskVariables(historicTask, variableMap, historyService, variableTransformer);
        }

        transformVariables(variableMap);
        VariableUtil.createFlowableDatabasePayloadObject(variableMap, objectMapper);

        List<FormInstance> formInstances = formService.createFormInstanceQuery().taskId(taskId).list();
        if (formInstances != null && !formInstances.isEmpty()) {
            FormInstance formInstance = formInstances.get(0);
            Map<String, Object> savedFormVariables = ((FormServiceImpl) formService).getSavedFormVariables(formInstance);
            contentItemService.copyAndTransformSavedFormInstanceValues(savedFormVariables, variableMap);
        }


        return variableMap;
    }

    public FormInfo getTaskForm(String taskId) {
        String formKey = null;
        String processInstanceId = null;
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (task != null) {
            permissionService.validatePermissionForRuntimeScope(PermissionConstants.TASK_VIEW, taskId,
                getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());
            formKey = task.getFormKey();
            processInstanceId = task.getProcessInstanceId();

        } else {
            permissionService.validatePermissionForHistoricScope(PermissionConstants.TASK_VIEW, taskId,
                getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());
            HistoricTaskInstance historicTask = historyService.createHistoricTaskInstanceQuery().taskId(taskId).singleResult();
            formKey = historicTask.getFormKey();
            processInstanceId = historicTask.getProcessInstanceId();
        }

        if (StringUtils.isEmpty(formKey)) {
            throw new FlowableObjectNotFoundException(String.format("Task has no form with task id: %s", taskId));
        }

        FormInfo taskFormInfo;
        if (processInstanceId != null) {
            taskFormInfo = taskService.getTaskFormModel(taskId, true);
        } else {
            taskFormInfo = cmmnTaskService.getTaskFormModel(taskId, true);
        }

        FlowableFormModel formModel = (FlowableFormModel) taskFormInfo.getFormModel();
        FormModelUtil.decorateFormModel(formModel, taskId);

        return taskFormInfo;
    }

    public RestIdentityLink addIdentityLink(String taskId, RestIdentityLink identityLink) {
        permissionService.validatePermissionForRuntimeScope(PermissionConstants.TASK_EDIT, taskId,
            getCurrentUserId(), getCurrentGroupKeys(), getCurrentTenantId());

        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        if (identityLink.getGroup() == null && identityLink.getUser() == null) {
            throw new FlowableIllegalArgumentException("A group or a user is required to create an identity link.");
        }

        if (identityLink.getGroup() != null && identityLink.getUser() != null) {
            throw new FlowableIllegalArgumentException("Only one of user or group can be used to create an identity link.");
        }

        if (identityLink.getType() == null) {
            throw new FlowableIllegalArgumentException("The identity link type is required.");
        }

        if (task.getScopeId() != null && ScopeTypes.CMMN.equals(task.getScopeType())) {
            if (identityLink.getGroup() != null) {
                cmmnTaskService.addGroupIdentityLink(task.getId(), identityLink.getGroup(), identityLink.getType());
            } else {
                cmmnTaskService.addUserIdentityLink(task.getId(), identityLink.getUser(), identityLink.getType());
            }

        } else {
            if (identityLink.getGroup() != null) {
                taskService.addGroupIdentityLink(task.getId(), identityLink.getGroup(), identityLink.getType());
            } else {
                taskService.addUserIdentityLink(task.getId(), identityLink.getUser(), identityLink.getType());
            }
        }

        RestIdentityLink resultIdentityLink = new RestIdentityLink();
        resultIdentityLink.setType(identityLink.getType());
        resultIdentityLink.setUser(identityLink.getUser());
        resultIdentityLink.setGroup(identityLink.getGroup());
        return resultIdentityLink;
    }

    protected void transformVariables(Map<String, Object> variables) {
        if (contentItemService != null) {
            for (String variableName : variables.keySet()) {
                Object variableValue = variables.get(variableName);
                contentItemService.handleContentItem(variableName, variableValue, variables);
            }
        }
    }

    protected Map<String, Object> mapAttachmentsToContentItems(Map<String, Object> formVariables) {
        Map<String, Object> attachments = new LinkedHashMap<>();
        formVariables.forEach((key, value) -> {
            if (value instanceof List && !((List) value).isEmpty() && ((List) value).get(0) instanceof Map) {
                List<Map<String, Object>> valuesList = (List<Map<String, Object>>) value;
                Set<String> contentItemIdSet = new HashSet<>();
                valuesList.forEach(listValue -> {
                    if (listValue.containsKey("contentStoreId")) {
                        contentItemIdSet.add((String) listValue.get("id"));
                    }
                });

                if (!contentItemIdSet.isEmpty()) {
                    List<CoreContentItem> contentItems = contentService.createCoreContentItemQuery().ids(contentItemIdSet).list();
                    attachments.put(key, contentItems);
                }
            }
        });

        return attachments;
    }

    protected TaskRepresentation createTaskRepresentation(Task task) {

        TaskRepresentation taskRepresentation = createTaskRepresentationFromInfo(task);
        taskRepresentation.setDelegationState(getDelegationStateString(task.getDelegationState()));
        taskRepresentation.setSuspended(task.isSuspended());

        return taskRepresentation;
    }

    protected TaskRepresentation createTaskRepresentation(HistoricTaskInstance task) {

        TaskRepresentation taskRepresentation = createTaskRepresentationFromInfo(task);
        taskRepresentation.setEndTime(task.getEndTime());

        return taskRepresentation;
    }

    protected TaskRepresentation createTaskRepresentationFromInfo(TaskInfo task) {
        TaskRepresentation taskRepresentation = new TaskRepresentation();
        taskRepresentation.setId(task.getId());
        taskRepresentation.setOwner(task.getOwner());
        taskRepresentation.setAssignee(task.getAssignee());
        taskRepresentation.setName(task.getName());
        taskRepresentation.setDescription(task.getDescription());
        taskRepresentation.setStartTime(task.getCreateTime());
        taskRepresentation.setCreateTime(task.getCreateTime());
        taskRepresentation.setDueDate(task.getDueDate());
        taskRepresentation.setPriority(task.getPriority());
        taskRepresentation.setClaimTime(task.getClaimTime());
        taskRepresentation.setTaskDefinitionKey(task.getTaskDefinitionKey());
        taskRepresentation.setParentTaskId(task.getParentTaskId());
        taskRepresentation.setExecutionId(task.getExecutionId());
        taskRepresentation.setCategory(task.getCategory());
        taskRepresentation.setProcessInstanceId(task.getProcessInstanceId());
        taskRepresentation.setProcessDefinitionId(task.getProcessDefinitionId());
        taskRepresentation.setScopeDefinitionId(task.getScopeDefinitionId());
        taskRepresentation.setScopeId(task.getScopeId());
        taskRepresentation.setScopeType(task.getScopeType());
        taskRepresentation.setTenantId(task.getTenantId());
        taskRepresentation.setFormKey(task.getFormKey());

        return taskRepresentation;
    }

    protected String getDelegationStateString(DelegationState state) {
        String result = null;
        if (state != null) {
            result = state.toString().toLowerCase();
        }
        return result;
    }
}
